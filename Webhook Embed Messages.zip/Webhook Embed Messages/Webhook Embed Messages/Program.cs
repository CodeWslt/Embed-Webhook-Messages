﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Webhook_Embed_Messages
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Title = "Embed Webhook Sender - By Wslt";
            string Webhook = string.Empty;
            string Title = string.Empty;
            string Desc = string.Empty;
            string Webhookname = string.Empty;
            string WebhookPfp = string.Empty;
            Console.WriteLine("Webhook Url?");
            Webhook = Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Title?");
            Title = Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Desc?");
            Desc = Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Webhook Name?");
            Webhookname = Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Webhook Pfp Url?");
            WebhookPfp = Console.ReadLine();
            SendWebhook(Webhook, Title, Desc, Webhookname, WebhookPfp);
            Console.Clear();
            Console.WriteLine("Message Sent!");
            Console.ReadLine();
        }


        static void SendWebhook(string Webhook, string Title, string Desc, string Webhookname, string WebhookPfp)
        {
            WebRequest wr = (HttpWebRequest)WebRequest.Create(Webhook);

            wr.ContentType = "application/json";

            wr.Method = "POST";

            using (var sw = new StreamWriter(wr.GetRequestStream()))
            {
                string json = JsonConvert.SerializeObject(new
                {
                    username = Webhookname,
                    avatar_url = WebhookPfp,
                    embeds = new[]
                    {
                        new {
                            description = Desc,
                            title = Title,
                            color = "8464385",

                            footer = new {
                                icon_url = "",
                                text = "This Bot Uses fortnite-api.com"
                            },
                        }
                    }
                });

                sw.Write(json);
            }

            var response = (HttpWebResponse)wr.GetResponse();
        }
    }
}
